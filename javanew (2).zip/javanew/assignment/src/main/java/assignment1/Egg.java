package assignment1;

import java.util.Scanner;

public class Egg {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of eggs");
		int x = sc.nextInt();
		int y = x/144;
		int z = x%144;
		int d = z/12;
		int e = z%12;
		System.out.println("Your number of eggs is "+y+" gross, "+d+" dozen, and left "+e);
		sc.close();
	}
}
	

