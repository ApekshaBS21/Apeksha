package assignment1;

public class Shape {
        public double areaSquare(double x) {
		return x * x;
		
	}
	
	public double areaRec(double x, double y) {
		return x * y;
		
	}
	
	public double perimeterSquare(double x) {
		
		return 4 * x;
	}
	
	public double perimeterRec(double x, double y) {
		
		return 2 * (x+y);
	}
	
	
	
	
	  
}
