package assignment1;

public class ShapeMain {

	public static void main(String[] args) {
		Shape s = new Shape();
		  double myNum1 = s.areaSquare(8.0);
		  double myNum2 = s.perimeterSquare(4.3);
		  double myNum3 = s.areaRec(8.0, 7.0);
		  double myNum4 = s.perimeterRec(4.3, 8.9);
		  System.out.println("area Square: " + myNum1);
		  System.out.println("perimeter Square: " + myNum2);
		  System.out.println("area Rec: " + myNum3);
		  System.out.println("perimeter Rec: " + myNum4);
		}


}
